package task1;
import java.util.Scanner;

public class TriangularSequence {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.close();

        int k = 1;      // текущее число
        int count = 0;  // сколько раз уже напечатали k
        for (int i = 0; i < n; i++) {
            System.out.print(k + " ");
            count++;
            if (count == k) {
                k++;
                count = 0;
            }
        }
        System.out.println();
    }
}