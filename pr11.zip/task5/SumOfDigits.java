import java.util.Scanner;

public class SumOfDigits {
    // Рекурсивный подсчёт суммы цифр
    static int sumDigits(int n) {
        if (n == 0) return 0;
        return (n % 10) + sumDigits(n / 10);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        sc.close();

        System.out.println(sumDigits(N));
    }
}