import java.util.Scanner;

public class DigitSumCount {
    // pos — текущая позиция (0..k-1)
    // sum — текущая сумма цифр
    // k — количество цифр
    // target — требуемая сумма
    // isFirst — первая цифра? (чтобы не ставить 0)
    static long count(int pos, int sum, int k, int target, boolean isFirst) {
        if (pos == k) {
            return (sum == target) ? 1 : 0;
        }
        if (sum > target) return 0; // оптимизация

        long total = 0;
        int start = isFirst ? 1 : 0;
        int end = 9;
        for (int digit = start; digit <= end; digit++) {
            total += count(pos + 1, sum + digit, k, target, false);
        }
        return total;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int k = sc.nextInt();
        int s = sc.nextInt();
        sc.close();

        // Проверка: минимальная сумма = 1 (для k>=1), максимальная = 9*k
        if (s < 1 || s > 9 * k) {
            System.out.println(0);
        } else {
            System.out.println(count(0, 0, k, s, true));
        }
    }
}