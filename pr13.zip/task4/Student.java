public class Student implements Comparable<Student> {
    private String name;
    private int iDNumber;
    private double gpa;

    public Student(String name, int iDNumber, double gpa) {
        this.name = name;
        this.iDNumber = iDNumber;
        this.gpa = gpa;
    }

    public String getName() { return name; }
    public int getIDNumber() { return iDNumber; }
    public double getGpa() { return gpa; }

    @Override
    public int compareTo(Student other) {
        // Сравнение по ID (по возрастанию)
        return Integer.compare(this.iDNumber, other.iDNumber);
    }

    @Override
    public String toString() {
        return String.format("Student{name='%s', ID=%d, GPA=%.2f}", name, iDNumber, gpa);
    }
}