import java.util.Arrays;

public class StudentInsertionSort {
    public static void insertionSortByID(Student[] students) {
        for (int i = 1; i < students.length; i++) {
            Student key = students[i];
            int j = i - 1;

            // Сдвигаем элементы, у которых ID > key.ID
            while (j >= 0 && students[j].getIDNumber() > key.getIDNumber()) {
                students[j + 1] = students[j];
                j--;
            }
            students[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        Student[] students = {
            new Student("Alice", 103, 3.7),
            new Student("Bob", 101, 3.9),
            new Student("Charlie", 102, 3.5)
        };

        System.out.println("До сортировки:");
        Arrays.stream(students).forEach(System.out::println);

        insertionSortByID(students);

        System.out.println("\nПосле сортировки по ID:");
        Arrays.stream(students).forEach(System.out::println);
    }
}