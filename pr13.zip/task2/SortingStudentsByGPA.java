import java.util.Comparator;

public class SortingStudentsByGPA implements Comparator<Student> {
    @Override
    public int compare(Student s1, Student s2) {
        // Сортировка по GPA по убыванию
        return Double.compare(s2.getGpa(), s1.getGpa()); // обратный порядок
    }

    // Реализация быстрой сортировки с использованием этого компаратора
    public void quickSort(Student[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private int partition(Student[] arr, int low, int high) {
        Student pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            // Используем compare() вместо прямого сравнения
            if (compare(arr[j], pivot) > 0) { // если arr[j] "больше" pivot'а (по GPA)
                i++;
                Student temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        Student temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}