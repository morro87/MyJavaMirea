interface Priceable {
 double getPrice();
}
class Product implements Priceable {
 private String name;
 private double price;
 public Product(String name, double price) {
 this.name = name;
 this.price = price;
 }
 @Override
 public double getPrice() {
 return price;
 }
 @Override
 public String toString() {
 return name + " - " + price + " руб.";
 }
}
class Service implements Priceable {
 private String name;
 private double hourlyRate;
 private int hours;
 public Service(String name, double hourlyRate, int hours) {
 this.name = name;
 this.hourlyRate = hourlyRate;
 this.hours = hours;
 }
 @Override
 public double getPrice() {
 return hourlyRate * hours;
 }
 @Override
 public String toString() {
 return name + " - " + getPrice() + " руб.";
 }
}
