enum Brand {
 DELL, HP, LENOVO, ASUS, ACER, APPLE
}
class Processor {
 private String model;
 private double frequency;
 public Processor(String model, double frequency) {
 this.model = model;
 this.frequency = frequency;
 }
 @Override
 public String toString() {
 return model + " " + frequency + "GHz";
 }
}
class Memory {
 private int size;
 private String type;
 public Memory(int size, String type) {
 this.size = size;
 this.type = type;
 }
 @Override
 public String toString() {
 return size + "GB " + type;
 }
}
class Monitor {
 private double diagonal;
 private String resolution;
 public Monitor(double diagonal, String resolution) {
 this.diagonal = diagonal;
 this.resolution = resolution;
 }
 @Override
 public String toString() {
 return diagonal + "\" " + resolution;
 }
}
class Computer {
 private Brand brand;
 private Processor processor;
 private Memory memory;
 private Monitor monitor;
 private double price;
 public Computer(Brand brand, Processor processor, Memory memory, Monitor
monitor, double price) {
 this.brand = brand;
 this.processor = processor;
 this.memory = memory;
 this.monitor = monitor;
 this.price = price;
 }
 public Brand getBrand() { return brand; }
 public double getPrice() { return price; }
 @Override
 public String toString() {
 return brand + " Computer: " + processor + ", " + memory + ", " +
monitor + " - " + price + " руб.";
 }
}
class ComputerShop {
 private Computer[] computers;
 private int count;
 public ComputerShop(int capacity) {
 computers = new Computer[capacity];
 count = 0;
 }
 public void addComputer(Computer computer) {
 if (count < computers.length) {
 computers[count++] = computer;
 System.out.println("Компьютер добавлен: " + computer);
 } else {
 System.out.println("Магазин полон!");
 }
 }
 public void removeComputer(Brand brand) {
 for (int i = 0; i < count; i++) {
 if (computers[i].getBrand() == brand) {
 System.out.println("Удален компьютер: " + computers[i]);
 for (int j = i; j < count - 1; j++) {
 computers[j] = computers[j + 1];
 }
 count--;
 return;
 }
 }
 System.out.println("Компьютер марки " + brand + " не найден");
 }
 public Computer findComputer(Brand brand, double maxPrice) {
 for (int i = 0; i < count; i++) {
 if (computers[i].getBrand() == brand && computers[i].getPrice()
<= maxPrice) {
 return computers[i];
 }
 }
 return null;
 }
 public void displayComputers() {
 System.out.println("Компьютеры в магазине:");
 for (int i = 0; i < count; i++) {
 System.out.println((i + 1) + ". " + computers[i]);
 }
 }
}
