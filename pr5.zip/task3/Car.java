// Car.java
public class Car implements Nameable {
    private String name; // например, "Toyota Camry"
    private String brand;

    public Car(String name, String brand) {
        this.name = name;
        this.brand = brand;
    }

    @Override
    public String getName() {
        return name;
    }

    public String getBrand() {
        return brand;
    }

    @Override
    public String toString() {
        return String.format("Car{name='%s', brand='%s'}", name, brand);
    }
}