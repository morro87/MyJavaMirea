// Planet.java
public class Planet implements Nameable {
    private String name;
    private double distanceFromSun; // в млн км

    public Planet(String name, double distanceFromSun) {
        this.name = name;
        this.distanceFromSun = distanceFromSun;
    }

    @Override
    public String getName() {
        return name;
    }

    public double getDistanceFromSun() {
        return distanceFromSun;
    }

    @Override
    public String toString() {
        return String.format("Planet{name='%s', distanceFromSun=%.1f млн км}", name, distanceFromSun);
    }
}