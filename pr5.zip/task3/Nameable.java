// Nameable.java
public interface Nameable {
    String getName();
}