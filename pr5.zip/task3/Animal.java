// Animal.java
public class Animal implements Nameable {
    private String name;
    private String species;

    public Animal(String name, String species) {
        this.name = name;
        this.species = species;
    }

    @Override
    public String getName() {
        return name;
    }

    public String getSpecies() {
        return species;
    }

    @Override
    public String toString() {
        return String.format("Animal{name='%s', species='%s'}", name, species);
    }
}