import java.util.*;

// Основной класс — наш StringBuilder с поддержкой undo
public class UndoableStringBuilder {
    private StringBuilder sb = new StringBuilder();
    private Deque<Command> history = new ArrayDeque<>(); // стек команд

    // Интерфейс "Команда"
    private interface Command {
        void undo();
    }

    // Команда добавления строки
    private class AppendCommand implements Command {
        private final String value;
        private final int oldLength;

        public AppendCommand(String value) {
            this.value = value;
            this.oldLength = sb.length();
        }

        @Override
        public void undo() {
            sb.setLength(oldLength); // обрезаем до прежней длины
        }
    }

    // Команда удаления подстроки
    private class DeleteCommand implements Command {
        private final String deletedValue;
        private final int startIndex;

        public DeleteCommand(int start, int end) {
            this.startIndex = start;
            this.deletedValue = sb.substring(start, end);
        }

        @Override
        public void undo() {
            sb.insert(startIndex, deletedValue);
        }
    }

    // Команда замены (для replace)
    private class ReplaceCommand implements Command {
        private final String oldValue;
        private final int startIndex;

        public ReplaceCommand(int start, int end, String newValue) {
            this.startIndex = start;
            this.oldValue = sb.substring(start, end);
        }

        @Override
        public void undo() {
            sb.replace(startIndex, startIndex + oldValue.length(), oldValue);
        }
    }

    // ===== Публичные методы — делегирование + запись в историю =====

    public UndoableStringBuilder append(String str) {
        if (str == null) str = "null";
        history.push(new AppendCommand(str));
        sb.append(str);
        return this;
    }

    public UndoableStringBuilder delete(int start, int end) {
        checkBounds(start, end);
        history.push(new DeleteCommand(start, end));
        sb.delete(start, end);
        return this;
    }

    public UndoableStringBuilder replace(int start, int end, String str) {
        checkBounds(start, end);
        history.push(new ReplaceCommand(start, end, str));
        sb.replace(start, end, str);
        return this;
    }

    // Простой метод undo — откатывает последнюю операцию
    public UndoableStringBuilder undo() {
        if (history.isEmpty()) {
            System.out.println("Нет операций для отката.");
            return this;
        }
        Command last = history.pop();
        last.undo();
        return this;
    }

    // Вспомогательный метод для проверки границ
    private void checkBounds(int start, int end) {
        if (start < 0 || end > sb.length() || start > end) {
            throw new StringIndexOutOfBoundsException("Некорректные индексы: " + start + ", " + end);
        }
    }

    // Для удобства — toString и length
    @Override
    public String toString() {
        return sb.toString();
    }

    public int length() {
        return sb.length();
    }

    // ===== Пример использования =====
    public static void main(String[] args) {
        UndoableStringBuilder usb = new UndoableStringBuilder();

        usb.append("Hello")
           .append(" World")
           .replace(6, 11, "Java");

        System.out.println("Текущее значение: " + usb); // Hello Java

        usb.undo(); // откат replace → Hello World
        System.out.println("После undo: " + usb);       // Hello World

        usb.undo(); // откат append(" World")
        System.out.println("После undo: " + usb);       // Hello

        usb.undo(); // откат append("Hello")
        System.out.println("После undo: " + usb);       // (пусто)

        usb.undo(); // ничего нет — сообщение
    }
}