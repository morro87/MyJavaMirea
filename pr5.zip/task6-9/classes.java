interface Printable {
 void print();
}
class Book implements Printable {
 private String title;
 private String author;
 public Book(String title, String author) {
 this.title = title;
 this.author = author;
 }
 @Override
 public void print() {
 System.out.println("Книга: '" + title + "' автор: " + author);
 }
}
class Shop implements Printable {
 private String name;
 private String address;
 public Shop(String name, String address) {
 this.name = name;
 this.address = address;
 }
 @Override
 public void print() {
 System.out.println("Магазин: '" + name + "' адрес: " + address);
 }
}
