import java.io.*;
import java.util.Scanner;

public class Task1_WriteInputToFile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите текст для записи в файл:");
        String input = scanner.nextLine();
        scanner.close();

        try (FileWriter writer = new FileWriter("output.txt", false)) { // false = перезапись
            writer.write(input);
            System.out.println("Текст успешно записан в файл 'output.txt'");
        } catch (IOException e) {
            System.err.println("Ошибка записи: " + e.getMessage());
        }
    }
}