import java.io.*;
import java.util.Scanner;

public class Task4_AppendToFile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите текст для добавления в конец файла:");
        String appendText = scanner.nextLine();
        scanner.close();

        try (FileWriter writer = new FileWriter("output.txt", true)) { // true = дозапись
            writer.write("\n"); // добавляем новую строку
            writer.write(appendText);
            System.out.println("Текст успешно добавлен в конец файла.");
        } catch (IOException e) {
            System.err.println("Ошибка добавления: " + e.getMessage());
        }
    }
}