import java.io.*;

public class Task2_ReadFileToConsole {
    public static void main(String[] args) {
        try (FileReader reader = new FileReader("output.txt")) {
            int ch;
            System.out.println("Содержимое файла:");
            while ((ch = reader.read()) != -1) {
                System.out.print((char) ch);
            }
            System.out.println(); // новая строка в конце
        } catch (IOException e) {
            System.err.println("Ошибка чтения: " + e.getMessage());
        }
    }
}