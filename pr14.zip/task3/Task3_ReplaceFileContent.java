import java.io.*;
import java.util.Scanner;

public class Task3_ReplaceFileContent {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите новый текст для замены содержимого файла:");
        String newText = scanner.nextLine();
        scanner.close();

        try (FileWriter writer = new FileWriter("output.txt", false)) { // false = перезапись
            writer.write(newText);
            System.out.println("Содержимое файла успешно заменено.");
        } catch (IOException e) {
            System.err.println("Ошибка замены: " + e.getMessage());
        }
    }
}